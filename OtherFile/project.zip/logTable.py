import sqlite3
from datetime import datetime

# from wiringthread import mytable


sqlite_file = 'toiletData.db'
conn = sqlite3.connect(sqlite_file)


def create_table():
    cur = conn.cursor()
    cur.execute(
        "CREATE TABLE IF NOT EXISTS DATA(kinds INT, date_time DATETIME,mode INT, message TEXT , duration FLOAT )")
    cur.close()


def insert_table(kinds, date, mode, message, duration=0):
    cur = conn.cursor()
    cur.execute("INSERT INTO DATA(kinds, date_time, mode, message, duration) VALUES (?, ?, ?, ?,?)",
                (kinds, date, mode, message, duration))

    conn.commit()
    cur.close()
    return cur.lastrowid


def update_table(user_id, duration):
    cur = conn.cursor()
    cur.execute("UPDATE DATA SET duration = ? WHERE id=?", (duration, user_id))
    conn.commit()
    cur.close()


