# coding: UTF -8
import wiringpi as wiringpi
#from time import sleep
from datetime import datetime
import time
import threading
import pygame.mixer
from pygame.mixer import Sound


pygame.mixer.init(frequency=44000, size=-16, channels=2, buffer =4096)

GPIO_LED = 18
GPIO_SW = 17

wiringpi.wiringPiSetupGpio()

wiringpi.pinMode(GPIO_LED, 1)  # sets GPIO 18 to output
wiringpi.pinMode(GPIO_SW, 0)  # sets GPIO 17 to input
wiringpi.pullUpDnControl(GPIO_SW, wiringpi.PUD_DOWN)

wiringpi.digitalWrite(GPIO_LED, 0)  # sets port 18 to 0 (0V, on)

log2_file = "./LOG/log2.txt"
error2_log = "./LOG/error2_log.txt"
status2_log = "./LOG/status2_log.txt"
global channel1


channel0 = pygame.mixer.Channel(0)
channel0.set_volume(1.0, 0.0)

def alert():

    sound0 = pygame.mixer.Sound('/home/pi/Desktop/simple_flask/if.wav')
    sound1 = pygame.mixer.Sound('/home/pi/Desktop/simple_flask/zona.wav')
    sound2 = pygame.mixer.Sound('/home/pi/Desktop/simple_flask/celeina.wav')

    return sound0, sound1, sound2

s0, s1, s2 = alert()
def aa():
    print("男子 duration : 1  minutes")
    print("男子　Please go out")
    channel0.play(s0)

def bb():
    print("男子 duration : 2 minutes")
    print("男子　Please go ")
    channel0.play(s1)



def cc():
    print("男子 duration : 3  minutes")
    print("男子　Come the shop owner ")
    channel0.play(s2)

t = threading.Timer(60, aa)
t1 = threading.Timer(120, bb)
t2 = threading.Timer(180, cc)

def start_waiting():
    global t
    global t1
    global t2
    t = threading.Timer(60, aa)
    t1 = threading.Timer(120, bb)
    t2 = threading.Timer(180, cc)

    t.start()
    t1.start()
    t2.start()

def stop_waiting():
    t.cancel()
    t1.cancel()
    t2.cancel()

def start():
    read0 = 1

    while True:
        time.sleep(0.1)
        read1 = wiringpi.digitalRead(GPIO_SW)
        #        print "read1= %d" % read1


        if read0 == read1:

            continue

        time.sleep(0.05)
        read2 = wiringpi.digitalRead(GPIO_SW)
        start = datetime.now()
        end = datetime.now()
        #        print "read0= %d" % read0
        if read1 == read2:
            if read1 == 1:
                start_waiting()
                wiringpi.digitalWrite(GPIO_LED, 0) # switch on LED. Sets port 18 to 1 (3V3, on)
                store2_log("女子 トイレ使用開始\n")
                status2("Busy")
                print "\n 女子トイレ使用開始"



            else:
                stop_waiting()
                wiringpi.digitalWrite(GPIO_LED, 1) # switch off LED. Sets port 18 to 0 (0V, off)
                pygame.mixer.music.stop()
                store2_log("女子 トイレ使用終了\n")
                status2("Free")
                print "\n女子トイレ使用終了"


        read0 = read1



def store2_log(log):
    now = datetime.now()
    date_time = now.strftime("[%Y/%m/%d  %H:%M:%S]")
    text_log = date_time + " " + log
    try:
        f = open(log2_file, "a+")
        f = f.write(text_log)
        f.close()
    except:
        store_error2("file open error!!\n")


def status2(log):
    #   print(log)
    try:
        f = open(status2_log, "w+")
        f.write(log)
        f.close()
    except:
        store_error2("file open error!!\n")


def store_error2(log):
    now = datetime.now()
    date_time = now.strftime("[%Y/%m/%d  %H:%M:%S]")
    text_log = date_time + " " + log
    try:
        f = open(error2_log, "a+")
        f.write(text_log)
        f.close()
    except:
        print("ERROR")

x1= threading.Thread(target = start)
x1.start()


