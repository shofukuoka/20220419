# coding: UTF -8
import wiringpi as wiringpi
from time import sleep
from datetime import datetime
import time
import threading
import pygame

pygame.mixer.init(frequency=44000, size=-16, channels=2, buffer =4096)



GPIO_LED = 12
GPIO_SW = 26

wiringpi.wiringPiSetupGpio()

wiringpi.pinMode(GPIO_LED, 1)  # sets GPIO 12 to output
wiringpi.pinMode(GPIO_SW, 0)  # sets GPIO 26 to input
wiringpi.pullUpDnControl(GPIO_SW, wiringpi.PUD_DOWN)

wiringpi.digitalWrite(GPIO_LED, 0)  # sets port 26 to 0 (0V, on)

log_file = "./LOG/log.txt"
error_log = "./LOG/error_log.txt"
status_log = "./LOG/status_log.txt"

channel0 = pygame.mixer.Channel(0)
channel0.set_volume(1.0, 0.0)

def alert():

    sound0 = pygame.mixer.Sound('/home/pi/Desktop/simple_flask/if.wav')
    sound1 = pygame.mixer.Sound('/home/pi/Desktop/simple_flask/zona.wav')
    sound2 = pygame.mixer.Sound('/home/pi/Desktop/simple_flask/celeina.wav')

    return sound0, sound1, sound2

s0, s1, s2 = alert()
def aa():
    print("男子 duration : 1  minutes")
    print("男子　Please go out")
    channel0.play(s0)





def bb():
    print("男子 duration : 2 minutes")
    print("男子　Please go ")
    channel0.play(s1)



def cc():
    print("男子 duration : 3  minutes")
    print("男子　Come the shop owner ")
    channel0.play(s2)



t = threading.Timer(60, aa)
t1 = threading.Timer(120, bb)
t2 = threading.Timer(180, cc)
def start_waiting():
    global t
    global t1
    global t2
    t = threading.Timer(60, aa)
    t1 = threading.Timer(120, bb)
    t2 = threading.Timer(180, cc)

    t.start()
    t1.start()
    t2.start()

def stop_waiting():

    t.cancel()
    t1.cancel()
    t2.cancel()

def start():

    read0 = 1

    while True:

        time.sleep(0.1)
        read1 = wiringpi.digitalRead(GPIO_SW)
        #        print "read1= %d" % read1
        if read0 == read1:
            continue

        time.sleep(0.05)
        read2 = wiringpi.digitalRead(GPIO_SW)
        #        print "read0= %d" % read0
        if read1 == read2:
            if read1 == 1:
                start_waiting()
                wiringpi.digitalWrite(GPIO_LED, 0) # switch on LED. Sets port 12 to 1 (3V3, on)

                store_log("男子 トイレ使用開始\n")
                status("Busy")
                print "\n 男子トイレ使用開始"


            else:
                stop_waiting()
                wiringpi.digitalWrite(GPIO_LED, 1) # switch off LED. Sets port 12 to 0 (0V, off)
                pygame.mixer.music.stop()
                store_log("男子トイレ使用終了\n")
                status("Free")
                print "\n男子トイレ使用終了"

        read0 = read1



def store_log(log):
    now = datetime.now()
    date_time = now.strftime("[%Y/%m/%d  %H:%M:%S]")
    text_log = date_time + " " + log
    try:
        f = open(log_file, "a+")
        f = f.write(text_log)
        f.close()
    except:
        store_error("file open error!!\n")


def status(log):
    #   print(log)
    try:
        f = open(status_log, "w+")
        f.write(log)
        f.close()
    except:
        store_error("file open error!!\n")


def store_error(log):
    now = datetime.now()
    date_time = now.strftime("[%Y/%m/%d  %H:%M:%S]")
    text_log = date_time + " " + log
    try:
        f = open(error_log, "a+")
        f.write(text_log)
        f.close()
    except:
        print("ERROR")

x= threading.Thread(target = start)
x.start()




